# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Standard task encoder for packing pre-tokenized text (bin-idx) into fixed-length sequences.

Provides the canonical packing pipeline:
  1. Cook bin-idx raw samples into TokenSample
  2. Preencode: shift tokens to produce labels
  3. Split oversized documents into sequence-length chunks
  4. Pack via greedy knapsack
  5. Batch into {"tokens": ..., "labels": ...} dicts
"""

import random
from dataclasses import dataclass
from typing import Generator, List

import torch

from megatron.energon.edataclass import edataclass
from megatron.energon.flavors import Sample
from megatron.energon.task_encoder.base import TaskEncoder, stateless
from megatron.energon.task_encoder.cooking import Cooker, basic_sample_keys, cooker
from megatron.energon.task_encoder.knapsack import greedy_knapsack

IGNORE_INDEX = -100


# ---------------------------------------------------------------------------
# Sample types
# ---------------------------------------------------------------------------
@edataclass
class TokenSample(Sample):
    """A single document as a 1-D token tensor (output of the bin-idx cooker)."""

    tokens: torch.Tensor


@dataclass
class EncodedSample:
    """Tokens with shifted labels, ready for packing."""

    tokens: torch.Tensor
    labels: torch.Tensor
    total_len: int


@dataclass
class PackedSample:
    """A fixed-length packed sequence of tokens and labels."""

    tokens: torch.Tensor
    labels: torch.Tensor


# ---------------------------------------------------------------------------
# Cooker: bin-idx raw sample -> TokenSample
# ---------------------------------------------------------------------------
@stateless
@cooker()
def cook_bin_idx_tokens(sample: dict) -> TokenSample:
    """Cook a raw bin-idx sample dict into a TokenSample."""
    tokens = sample["tokens"]  # np.ndarray(int32)
    return TokenSample(
        **basic_sample_keys(sample),
        tokens=torch.as_tensor(tokens, dtype=torch.long),
    )


# ---------------------------------------------------------------------------
# Task encoder
# ---------------------------------------------------------------------------
class TextPackingEncoder(TaskEncoder[TokenSample, EncodedSample, PackedSample, dict]):
    """Packs pre-tokenized text documents into fixed-length sequences.

    Args:
        seq_length: Target packed sequence length.
        pad_id: Token ID used for padding (default 0).
        ignore_index: Label value for positions to ignore in loss (default -100).
    """

    cookers = [Cooker(cook_bin_idx_tokens, has_subflavors={"cook": "bin_idx"})]

    def __init__(self, seq_length: int, pad_id: int = 0, ignore_index: int = IGNORE_INDEX):
        super().__init__()
        self.seq_length = seq_length
        self.pad_id = pad_id
        self.ignore_index = ignore_index

    @stateless
    def preencode_sample(self, sample: TokenSample) -> EncodedSample:
        tokens = sample.tokens
        labels = torch.full_like(tokens, self.ignore_index)
        labels[:-1] = tokens[1:]
        return EncodedSample(
            tokens=tokens,
            labels=labels,
            total_len=len(tokens),
        )

    @stateless
    def split_sample_for_packing(
        self, sample: EncodedSample
    ) -> Generator[EncodedSample, None, None]:
        max_len = self.seq_length
        if sample.total_len <= max_len:
            yield sample
            return

        for start in range(0, sample.total_len, max_len):
            chunk_tokens = sample.tokens[start : start + max_len]
            chunk_labels = sample.labels[start : start + max_len]
            yield EncodedSample(
                tokens=chunk_tokens,
                labels=chunk_labels,
                total_len=len(chunk_tokens),
            )

    @stateless
    def select_samples_to_pack(
        self, samples: List[EncodedSample]
    ) -> List[List[EncodedSample]]:
        lengths = [s.total_len for s in samples]
        packed = greedy_knapsack(lengths, samples, self.seq_length)
        random.shuffle(packed)
        return packed

    @stateless
    def pack_selected_samples(self, samples: List[EncodedSample]) -> PackedSample:
        all_tokens = torch.cat([s.tokens for s in samples])
        all_labels = torch.cat([s.labels for s in samples])
        pad_needed = self.seq_length - len(all_tokens)
        if pad_needed > 0:
            all_tokens = torch.cat(
                [all_tokens, torch.full((pad_needed,), self.pad_id, dtype=torch.long)]
            )
            all_labels = torch.cat(
                [all_labels, torch.full((pad_needed,), self.ignore_index, dtype=torch.long)]
            )
        return PackedSample(tokens=all_tokens, labels=all_labels)

    def batch(self, samples: List[PackedSample]) -> dict:
        return {
            "tokens": torch.stack([s.tokens for s in samples]),
            "labels": torch.stack([s.labels for s in samples]),
        }
