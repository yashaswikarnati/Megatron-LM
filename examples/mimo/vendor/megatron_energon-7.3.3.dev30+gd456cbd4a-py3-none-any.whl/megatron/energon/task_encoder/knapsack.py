# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Greedy knapsack packing algorithm for fitting variable-length samples into fixed-capacity bins."""

import bisect
from typing import List, TypeVar

T = TypeVar("T")


def greedy_knapsack(item_sizes: List[int], samples: List[T], max_capacity: int) -> List[List[T]]:
    """Pack samples into bins using a greedy largest-fitting-first algorithm.

    Args:
        item_sizes: Size of each sample (must be <= max_capacity).
        samples: The sample objects corresponding to each size.
        max_capacity: Maximum total size per bin.

    Returns:
        List of bins, where each bin is a list of samples that fit within max_capacity.
    """
    if not item_sizes:
        return []
    sorted_pairs = sorted(zip(item_sizes, samples), key=lambda x: x[0])
    sorted_sizes = [s for s, _ in sorted_pairs]
    sorted_samps = [s for _, s in sorted_pairs]
    if sorted_sizes[-1] > max_capacity:
        raise ValueError(
            f"Sample larger ({sorted_sizes[-1]}) than max_capacity ({max_capacity})"
        )
    knapsacks: List[List[T]] = []
    while sorted_sizes:
        current: List[T] = []
        remaining = max_capacity
        while True:
            idx = bisect.bisect(sorted_sizes, remaining) - 1
            if idx < 0:
                break
            remaining -= sorted_sizes.pop(idx)
            current.append(sorted_samps.pop(idx))
        knapsacks.append(current)
    return knapsacks
