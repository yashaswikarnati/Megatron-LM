# Copyright (c) 2025, NVIDIA CORPORATION.  All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause

"""Cooker for megatron-vlm conversation format → MultiModalSample.

Reads the megatron-vlm SFT data format (conversation/sender/fragments) and
produces the same MultiModalSample that MultiModalPackingEncoder expects.

Expected JSON structure (inside each tar's .json file)::

    {
        "conversation": [
            {
                "sender": "user",
                "fragments": [
                    {"t": "image", "value": "path/to/image.png"},
                    {"t": "text", "value": "What is in this image?"}
                ]
            },
            {
                "sender": "assistant",
                "fragments": [
                    {"t": "text", "value": "A cat sitting on a mat."}
                ]
            }
        ]
    }

Fragment types:
    - {"t": "text", "value": "..."} — plain text
    - {"t": "image", "value": "path"} — image reference
    - Plain string fragments (legacy) — treated as text

Images are loaded from:
    1. The tar shard itself (if the image extension key exists in sample)
    2. The media_source filesystem path (from dataset YAML aux config)
"""

from megatron.energon import FileStore
from megatron.energon.task_encoder.base import stateless
from megatron.energon.task_encoder.cooking import basic_sample_keys, cooker
from megatron.energon.task_encoder.multimodal.cookers._image_util import to_pil_image
from megatron.energon.task_encoder.multimodal.sample_types import (
    ImageRef,
    MultiModalSample,
)


def _format_vlm_conversation(conversation: list[dict]) -> tuple[str, list[str]]:
    """Format megatron-vlm conversation into plain text with <image> placeholders.

    Produces flat text with no role prefixes — just concatenated content
    separated by newlines, with ``<image>`` tags where images appear.

    Returns:
        (text, image_paths): The formatted text and list of image paths in order.
    """
    parts = []
    image_paths = []

    for msg in conversation:
        msg_parts = []
        for frag in msg["fragments"]:
            if isinstance(frag, str):
                # Legacy plain string fragment
                msg_parts.append(frag)
            elif frag["t"] == "text":
                msg_parts.append(frag["value"])
            elif frag["t"] == "image":
                msg_parts.append("<image>")
                image_paths.append(frag["value"])
            # Skip unknown fragment types (video, audio) silently for now

        msg_text = "".join(msg_parts).strip()
        if msg_text:
            parts.append(msg_text)

    return "\n".join(parts), image_paths


@stateless
@cooker(need_cache=False)
def cook_vlm_conversation(
    sample: dict,
    media_source: FileStore = None,
) -> MultiModalSample:
    """Cook megatron-vlm conversation format into a MultiModalSample.

    Reads the ``conversation``/``sender``/``fragments`` JSON structure used by
    megatron-vlm's eagle_sft datasets and produces the flat text + image refs
    that MultiModalPackingEncoder expects.

    Images are loaded from the tar shard or directly from the media_source
    filesystem path (no CachePool required).
    """
    data = sample["json"]
    conversation = data["conversation"]

    text, image_paths = _format_vlm_conversation(conversation)

    tag_count = text.count("<image>")
    assert tag_count == len(image_paths), (
        f"Mismatch: {tag_count} <image> tags but {len(image_paths)} image paths "
        f"in sample {sample.get('__key__', '?')}"
    )

    # Load images
    image_refs = []
    for img_path in image_paths:
        # Try loading from shard first (polylithic: image bytes stored alongside json)
        ext = img_path.rsplit(".", 1)[-1] if "." in img_path else ""
        if ext in sample:
            img = to_pil_image(sample[ext])
        elif media_source is not None:
            # Load directly from the media_source filesystem
            img_data = media_source.get(img_path)
            img = to_pil_image(img_data)
        else:
            raise ValueError(
                f"Cannot load image {img_path!r}: not in shard and no media_source configured"
            )
        w, h = img.size
        image_refs.append(ImageRef(data=img, width=w, height=h))

    return MultiModalSample(
        **basic_sample_keys(sample),
        text=text,
        images=image_refs,
    )
