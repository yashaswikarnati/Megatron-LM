# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Cooker for MINT/arXiv interleaved image+text documents.

Expected format in sample["json"]::

    {"texts": [str|None, ...], "images": [str|None, ...]}

Parallel arrays — at each index, exactly one is non-None.
Non-None images map positionally to pages in sample["tiff"] (multi-page TIFF).

Requires ``decoder: null`` in dataset.yaml so that TIFF arrives as raw bytes
(the default decoder decodes to a single-frame tensor, losing multi-page info).
"""

import json as _json

from megatron.energon.task_encoder.base import stateless
from megatron.energon.task_encoder.cooking import basic_sample_keys, cooker
from megatron.energon.task_encoder.multimodal.cookers._image_util import (
    extract_tiff_pages,
)
from megatron.energon.task_encoder.multimodal.sample_types import (
    ImageRef,
    MultiModalSample,
)

IMAGE_TAG = "<image>"


def _reconstruct_interleaved(texts, images):
    """Walk parallel arrays → (text_with_image_tags, num_images)."""
    parts = []
    num_images = 0
    for i in range(max(len(texts), len(images))):
        txt = texts[i] if i < len(texts) else None
        img = images[i] if i < len(images) else None
        if txt is not None:
            parts.append(txt)
        if img is not None:
            parts.append(IMAGE_TAG)
            num_images += 1
    return "".join(parts), num_images


@stateless
@cooker(need_cache=False)
def cook_interleaved(sample: dict) -> MultiModalSample:
    # Handle both decoder:null (bytes) and auto-decoded (dict) JSON
    data = sample["json"]
    if isinstance(data, bytes):
        data = _json.loads(data)

    texts = data["texts"]
    images = data.get("images", [])

    text, num_images = _reconstruct_interleaved(texts, images)

    # Extract images from multi-page TIFF (pages map 1:1 to non-None image entries)
    image_refs = []
    if num_images > 0 and "tiff" in sample:
        tiff = sample["tiff"]
        if not isinstance(tiff, bytes):
            raise TypeError(
                f"sample['tiff'] must be raw bytes for multi-page extraction, "
                f"got {type(tiff).__name__}. Set decoder: null in dataset.yaml."
            )
        pages = extract_tiff_pages(tiff)
        if len(pages) < num_images:
            raise ValueError(
                f"TIFF has {len(pages)} pages but {num_images} image refs "
                f"in sample {sample.get('__key__', '?')}"
            )
        for img in pages[:num_images]:
            w, h = img.size
            image_refs.append(ImageRef(data=img, width=w, height=h))

    return MultiModalSample(
        **basic_sample_keys(sample),
        text=text,
        images=image_refs,
    )
