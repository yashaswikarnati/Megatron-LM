# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Cooker for NVMINT image-caption pairs (json+jpg format).

Expected: sample["json"] has caption/captions field, sample["jpg"] is the image.
"""

import json as _json

from megatron.energon.task_encoder.base import stateless
from megatron.energon.task_encoder.cooking import basic_sample_keys, cooker
from megatron.energon.task_encoder.multimodal.cookers._image_util import to_pil_image
from megatron.energon.task_encoder.multimodal.sample_types import (
    ImageRef,
    MultiModalSample,
)

_IMG_EXTS = ("jpg", "jpeg", "png", "webp")


@stateless
@cooker(need_cache=False)
def cook_nvmint_imgcaption(sample: dict) -> MultiModalSample:
    data = sample["json"]
    if isinstance(data, bytes):
        data = _json.loads(data)

    caption = data.get("caption", "") or data.get("captions", "") or ""
    if isinstance(caption, list):
        caption = " ".join(c for c in caption if c)

    # Find image
    img_data = None
    for ext in _IMG_EXTS:
        if ext in sample:
            img_data = sample[ext]
            break

    if img_data is None:
        raise ValueError(f"No image in sample {sample.get('__key__', '?')}")

    img = to_pil_image(img_data)
    w, h = img.size

    return MultiModalSample(
        **basic_sample_keys(sample),
        text=f"<image>{caption}",
        images=[ImageRef(data=img, width=w, height=h)],
    )
