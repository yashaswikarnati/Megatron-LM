# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Multimodal task encoder for image+text pretraining and SFT.

Provides:
- MultiModalPackingEncoder: packs interleaved image+text into fixed-length sequences
- VisionConfig / PackingConfig: fully explicit configuration (no megatron.core dependency)
- Image tiling strategies: NoTiling, TilingV1, DynamicResolution, MatchTiling, MaskedTiling, TileDegradation
- Cookers: image_caption, interleaved, conversation, bin_idx
"""

from megatron.energon.task_encoder.multimodal.config import (
    PackingConfig,
    VisionConfig,
)
from megatron.energon.task_encoder.multimodal.encoder import MultiModalPackingEncoder
from megatron.energon.task_encoder.multimodal.sample_types import (
    ImageRef,
    MultiModalSample,
    PackedSample,
    PreEncodedSample,
)

__all__ = [
    "MultiModalPackingEncoder",
    "VisionConfig",
    "PackingConfig",
    "ImageRef",
    "MultiModalSample",
    "PreEncodedSample",
    "PackedSample",
]
