# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Cooker for webdataset image-caption pairs → MultiModalSample.

Expected webdataset sample structure::

    sample_000.jpg    # image bytes
    sample_000.txt    # caption text

The image tag ``<image>`` is prepended to the caption text so the encoder
knows where to insert image tokens.
"""

from megatron.energon.task_encoder.base import stateless
from megatron.energon.task_encoder.cooking import basic_sample_keys, cooker
from megatron.energon.task_encoder.multimodal.cookers._image_util import (
    to_pil_image,
)
from megatron.energon.task_encoder.multimodal.sample_types import (
    ImageRef,
    MultiModalSample,
)

# Extensions to check for image data in the webdataset sample
_IMAGE_EXTENSIONS = ("jpg", "jpeg", "png", "webp", "bmp", "tiff")


def _find_image_key(sample: dict) -> str | None:
    """Find the first image key in a webdataset sample dict."""
    for ext in _IMAGE_EXTENSIONS:
        if ext in sample:
            return ext
    return None


def _find_text_key(sample: dict) -> str | None:
    """Find the first text key in a webdataset sample dict."""
    for key in ("txt", "caption", "text"):
        if key in sample:
            return key
    return None


@stateless
@cooker()
def cook_image_caption(sample: dict) -> MultiModalSample:
    """Cook a webdataset image-caption pair into a MultiModalSample.

    Images are expected to be in the sample dict (decoded by energon's
    webdataset reader). Handles PIL Images, bytes, and torch.Tensor inputs.

    The resulting text is ``"<image>{caption}"`` — the encoder will replace
    the ``<image>`` tag with the appropriate number of vision tokens.
    """
    img_key = _find_image_key(sample)
    txt_key = _find_text_key(sample)
    if img_key is None:
        raise ValueError(f"No image found in sample keys: {list(sample.keys())}")
    if txt_key is None:
        raise ValueError(f"No text found in sample keys: {list(sample.keys())}")

    img = to_pil_image(sample[img_key])
    width, height = img.size

    # Get the caption text
    caption = sample[txt_key]
    if isinstance(caption, bytes):
        caption = caption.decode("utf-8")

    return MultiModalSample(
        **basic_sample_keys(sample),
        text=f"<image>{caption}",
        images=[ImageRef(data=img, width=width, height=height)],
    )
