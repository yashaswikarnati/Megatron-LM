# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Cooker for conversation/SFT data → MultiModalSample (plain text, no label masking).

For pretraining on SFT-format data: applies a chat template to format the
conversation as plain text, strips special chat-ML tokens, and extracts images.

Expected JSON structure::

    {
        "conversations": [
            {"from": "user", "value": "What is in <image>?"},
            {"from": "assistant", "value": "A cat sitting on a mat."}
        ],
        "image": ["path/to/image.jpg"]  // or "image": "path/to/image.jpg"
    }

The chat template simply concatenates turns with role prefixes. The ``<image>``
placeholder is preserved for the encoder to expand into vision tokens.
"""

import re

from megatron.energon import CachePool, FileStore
from megatron.energon.task_encoder.base import stateless
from megatron.energon.task_encoder.cooking import basic_sample_keys, cooker
from megatron.energon.task_encoder.multimodal.cookers._image_util import to_pil_image
from megatron.energon.task_encoder.multimodal.sample_types import (
    ImageRef,
    MultiModalSample,
)

# Map common sender names to canonical names
_SENDER_MAP = {
    "human": "user",
    "gpt": "assistant",
    "agent": "assistant",
    "system": "system",
    "user": "user",
    "assistant": "assistant",
}

# Map common media key variants to canonical key
_MEDIA_KEY_MAP = {
    "images": "image",
    "image": "image",
}

# Supported image tags in conversation text
_IMAGE_TAG_PATTERN = re.compile(r"<image(?:-\d+)?>")


def _format_conversation_plain(conversations: list[dict]) -> str:
    """Format conversation turns into plain text without chat-ML tokens."""
    parts = []
    for turn in conversations:
        sender = _SENDER_MAP.get(turn["from"], turn["from"])
        value = turn["value"].strip()
        if sender == "system":
            parts.append(value)
        else:
            parts.append(f"{sender}: {value}")
    return "\n".join(parts)


@stateless
@cooker(need_cache=True)
def cook_conversation_plain(
    sample: dict,
    cache: CachePool,
    media_source: FileStore = None,
) -> MultiModalSample:
    """Cook SFT conversation data into a plain-text MultiModalSample.

    All conversation turns are concatenated as plain text (no label masking,
    no chat-ML special tokens). Images referenced in the conversation are
    loaded and mapped to ``<image>`` placeholders.
    """
    data = sample["json"]
    conversations = data["conversations"]

    # Format as plain text
    text = _format_conversation_plain(conversations)

    # Normalize <image-1>, <image-2> etc. to just <image>
    text = _IMAGE_TAG_PATTERN.sub("<image>", text)

    # Find image paths
    image_paths = []
    for key, canonical in _MEDIA_KEY_MAP.items():
        if key in data:
            paths = data[key]
            if isinstance(paths, str):
                paths = [paths]
            image_paths.extend(paths)
            break

    # Count image tags vs paths
    tag_count = text.count("<image>")
    if tag_count > len(image_paths):
        raise ValueError(
            f"Found {tag_count} <image> tags but only {len(image_paths)} image paths "
            f"in sample {sample.get('__key__', '?')}"
        )

    # Load images
    image_refs = []
    for img_path in image_paths[:tag_count]:
        # Try loading from shard first
        ext = img_path.rsplit(".", 1)[-1] if "." in img_path else ""
        if ext in sample:
            img = to_pil_image(sample[ext])
        else:
            # Load from media source
            data = cache.get(media_source, img_path)
            img = to_pil_image(data)

        w, h = img.size
        image_refs.append(ImageRef(data=img, width=w, height=h))

    return MultiModalSample(
        **basic_sample_keys(sample),
        text=text,
        images=image_refs,
    )
