# Copyright (c) 2025, NVIDIA CORPORATION.  All rights reserved.
# Except portions as noted which are Copyright (c) 2023 OpenGVLab
# and licensed under the MIT license found in LICENSE.
# SPDX-License-Identifier: BSD-3-Clause

"""Image tiling strategies for vision-language pretraining.

Ported from multimodal_encoders/data_loading/image_processing.py with all
megatron.core dependencies removed. Configuration is explicit via constructor
parameters — no get_args().

Strategies:
    NoTilingStrategy — resize to fixed size, one tile.
    ImageTilingStrategyV1 — split into NxM tile grid (InternVL style).
    DynamicResolutionImageTilingStrategy — variable patches per image.
    MatchTilingDynamicResolutionStrategy — tiling aspect ratio + dynamic resolution.
    MaskedTilingDynamicResolutionStrategy — per-tile block-diagonal attention.
    TileDegradationStrategy — degrade tiles when token budget is exceeded.
"""

import math
import random
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np
import torch
from PIL import Image
from torchvision import transforms as T
from torchvision.transforms import Compose
from torchvision.transforms.functional import InterpolationMode

from megatron.energon.task_encoder.multimodal.sample_types import (
    ImageRef,
    ImageTilingParams,
)
from megatron.energon.task_encoder.multimodal.vision_tokens import (
    get_num_image_embeddings,
)

# ---------------------------------------------------------------------------
# Pixel normalization statistics per vision model family
# ---------------------------------------------------------------------------
IMAGENET_PIXEL_MEAN = [0.485, 0.456, 0.406]
IMAGENET_PIXEL_STD = [0.229, 0.224, 0.225]
SIGLIP_PIXEL_MEAN = [0.5, 0.5, 0.5]
SIGLIP_PIXEL_STD = [0.5, 0.5, 0.5]
CLIP_PIXEL_MEAN = [0.48145466, 0.4578275, 0.40821073]
CLIP_PIXEL_STD = [0.26862954, 0.26130258, 0.27577711]
RADIO_G_PIXEL_MEAN = [0.4850, 0.4560, 0.4060]
RADIO_G_PIXEL_STD = [0.2230, 0.2240, 0.2250]

pixel_statistics: dict[str, tuple[list[float], list[float]]] = {
    "clip": (CLIP_PIXEL_MEAN, CLIP_PIXEL_STD),
    "siglip": (SIGLIP_PIXEL_MEAN, SIGLIP_PIXEL_STD),
    "internvit": (IMAGENET_PIXEL_MEAN, IMAGENET_PIXEL_STD),
    "radio": (CLIP_PIXEL_MEAN, CLIP_PIXEL_STD),
    "radio-so400m": (CLIP_PIXEL_MEAN, CLIP_PIXEL_STD),
    "radio-g": (RADIO_G_PIXEL_MEAN, RADIO_G_PIXEL_STD),
    "huggingface": (SIGLIP_PIXEL_MEAN, SIGLIP_PIXEL_STD),
    "radio_siglip_move": (CLIP_PIXEL_MEAN, CLIP_PIXEL_STD),
    "cradio-v1": (CLIP_PIXEL_MEAN, CLIP_PIXEL_STD),
    "cradio-g": (CLIP_PIXEL_MEAN, CLIP_PIXEL_STD),
}


# ---------------------------------------------------------------------------
# Aspect ratio helpers (from OpenGVLab/InternVL)
# ---------------------------------------------------------------------------
def find_closest_aspect_ratio(
    aspect_ratio: float,
    target_ratios: list[tuple[int, int]],
    width: int,
    height: int,
    image_size: int,
) -> tuple[int, int]:
    best_ratio_diff = float("inf")
    best_ratio = (1, 1)
    area = width * height
    for ratio in target_ratios:
        target_aspect_ratio = ratio[0] / ratio[1]
        ratio_diff = abs(aspect_ratio - target_aspect_ratio)
        if ratio_diff < best_ratio_diff:
            best_ratio_diff = ratio_diff
            best_ratio = ratio
        elif ratio_diff == best_ratio_diff:
            if area > 0.5 * image_size * image_size * ratio[0] * ratio[1]:
                best_ratio = ratio
    return best_ratio


def find_closest_area_weighted_aspect_ratio(
    aspect_ratio: float,
    target_ratios: list[tuple[int, int]],
    width: int,
    height: int,
    image_size: int,
) -> tuple[int, int]:
    best_factor = float("-inf")
    best_ratio = (1, 1)
    area = width * height
    for ratio in target_ratios:
        target_aspect_ratio = ratio[0] / ratio[1]
        factor_based_on_area_n_ratio = min(
            (ratio[0] * ratio[1] * image_size * image_size) / area, 0.6
        ) * min(target_aspect_ratio / aspect_ratio, aspect_ratio / target_aspect_ratio)
        if factor_based_on_area_n_ratio > best_factor:
            best_factor = factor_based_on_area_n_ratio
            best_ratio = ratio
    return best_ratio


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------
class ImageTilingStrategy(ABC):
    """Base class for image tiling strategies.

    Subclasses must implement ``compute_params`` and ``apply_params``.
    """

    @abstractmethod
    def compute_params(
        self,
        image_refs: list[ImageRef],
        num_tokens_available: int,
        max_num_tiles: int | None = None,
        **kwargs,
    ) -> list[ImageTilingParams]:
        """Compute tiling parameters without materializing images."""
        ...

    @abstractmethod
    def apply_params(
        self, params: ImageTilingParams, **kwargs
    ) -> list[torch.Tensor]:
        """Materialize images and apply tiling. Returns list of (C,H,W) tensors."""
        ...

    @abstractmethod
    def stack(
        self, images: list[torch.Tensor]
    ) -> tuple[
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor | None,
    ]:
        """Stack image tiles into a batch tensor."""
        ...


# ---------------------------------------------------------------------------
# Shared transform builder
# ---------------------------------------------------------------------------
def _build_transform(target_size: tuple[int, int], vision_model_type: str):
    """Build a torchvision transform for a given vision model type."""
    if vision_model_type in pixel_statistics:
        pixel_mean, pixel_std = pixel_statistics[vision_model_type]
    else:
        raise NotImplementedError(
            f"Image processing not defined for vision model {vision_model_type!r}. "
            f"Supported: {sorted(pixel_statistics)}"
        )

    return T.Compose(
        [
            T.Lambda(lambda img: img.convert("RGB") if img.mode != "RGB" else img),
            T.Resize(
                (target_size[1], target_size[0]),
                interpolation=InterpolationMode.BICUBIC,
            ),
            T.ToTensor(),
            T.Normalize(mean=pixel_mean, std=pixel_std),
        ]
    )


class _FixedSizeStrategy(ImageTilingStrategy):
    """Base for strategies that produce fixed-size tiles."""

    def __init__(
        self,
        vision_model_type: str,
        target_width: int,
        target_height: int,
        embeddings_per_image: int,
    ):
        self._vision_model_type = vision_model_type
        self._target_width = target_width
        self._target_height = target_height
        self._embeddings_per_image = embeddings_per_image
        self._transform = _build_transform(
            (target_width, target_height), vision_model_type
        )

    def stack(
        self, images: list[torch.Tensor]
    ) -> tuple[
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor | None,
    ]:
        if not images:
            return None, None, None, None
        return (
            torch.stack(images),
            torch.tensor(
                [(img.shape[1], img.shape[2]) for img in images], dtype=torch.int32
            ),
            None,
            None,
        )


# ---------------------------------------------------------------------------
# Strategy 1: No tiling — resize to fixed size
# ---------------------------------------------------------------------------
class NoTilingStrategy(_FixedSizeStrategy):
    """Resize image to fixed target dimensions. One tile per image."""

    def compute_params(
        self,
        image_refs: list[ImageRef],
        num_tokens_available: int | None = None,
        max_num_tiles: int | None = None,
        **kwargs,
    ) -> list[ImageTilingParams]:
        return [
            ImageTilingParams(
                image_ref=ref,
                num_tiles=1,
                num_embeddings=self._embeddings_per_image,
            )
            for ref in image_refs
        ]

    def apply_params(self, params: ImageTilingParams, **kwargs) -> list[torch.Tensor]:
        return [self._transform(params.image_ref.data)]


# ---------------------------------------------------------------------------
# Strategy 2: Tiling V1 — NxM grid (InternVL style)
# ---------------------------------------------------------------------------
@dataclass
class ImageTilingParamsV1(ImageTilingParams):
    tiling: tuple[int, int] = (1, 1)


class ImageTilingStrategyV1(_FixedSizeStrategy):
    """Split image into an NxM grid of tiles with optional thumbnail."""

    def __init__(
        self,
        vision_model_type: str,
        tile_size: int,
        use_thumbnail: bool,
        min_num_tiles: int,
        max_num_tiles: int,
        embeddings_per_tile: int,
        find_closest_aspect_ratio_fn=find_closest_aspect_ratio,
    ):
        super().__init__(
            vision_model_type=vision_model_type,
            target_width=tile_size,
            target_height=tile_size,
            embeddings_per_image=embeddings_per_tile,
        )
        self._tile_size = tile_size
        self._use_thumbnail = use_thumbnail
        self._min_num_tiles = min_num_tiles
        self._max_num_tiles = max_num_tiles
        self._find_closest_aspect_ratio_fn = find_closest_aspect_ratio_fn

        # Pre-compute all possible aspect ratios for each max_num_tiles
        self.target_ratios = {
            mnt: sorted(
                set(
                    (x, y)
                    for n in range(self._min_num_tiles, mnt + 1)
                    for x in range(1, n + 1)
                    for y in range(1, n + 1)
                    if x * y <= mnt and x * y >= self._min_num_tiles
                ),
                key=lambda x: x[0] * x[1],
            )
            for mnt in range(self._min_num_tiles, self._max_num_tiles + 1)
        }

    def compute_params(
        self,
        image_refs: list[ImageRef],
        num_tokens_available: int | None = None,
        max_num_tiles: int | None = None,
        data_augment: bool = False,
        tiling_augment_prob: float = 0.4,
        **kwargs,
    ) -> list[ImageTilingParamsV1]:
        effective_max = min(
            max_num_tiles if max_num_tiles is not None else self._max_num_tiles,
            self._max_num_tiles,
        )
        if num_tokens_available is not None:
            effective_max = min(
                num_tokens_available // self._embeddings_per_image, effective_max
            )
        effective_max = max(effective_max, self._min_num_tiles)

        target_ratios = self.target_ratios[effective_max]
        params = []
        for ref in image_refs:
            aspect_ratio = ref.width / ref.height
            tiling = self._find_closest_aspect_ratio_fn(
                aspect_ratio, target_ratios, ref.width, ref.height, self._tile_size
            )
            if data_augment and random.random() < tiling_augment_prob:
                tiling = self._augment_tiling(tiling)
            num_tiles = tiling[0] * tiling[1]
            if self._use_thumbnail and num_tiles != 1:
                num_tiles += 1
            params.append(
                ImageTilingParamsV1(
                    image_ref=ref,
                    num_tiles=num_tiles,
                    num_embeddings=num_tiles * self._embeddings_per_image,
                    tiling=tiling,
                )
            )
        return params

    def apply_params(
        self, params: ImageTilingParams, data_augment: bool = False, **kwargs
    ) -> list[torch.Tensor]:
        assert isinstance(params, ImageTilingParamsV1)
        image = params.image_ref.data
        target_width = self._tile_size * params.tiling[0]
        target_height = self._tile_size * params.tiling[1]
        blocks = params.tiling[0] * params.tiling[1]

        resized_img = image.resize((target_width, target_height))
        processed = []
        for i in range(blocks):
            box = (
                (i % (target_width // self._tile_size)) * self._tile_size,
                (i // (target_width // self._tile_size)) * self._tile_size,
                ((i % (target_width // self._tile_size)) + 1) * self._tile_size,
                ((i // (target_width // self._tile_size)) + 1) * self._tile_size,
            )
            processed.append(resized_img.crop(box))
        if self._use_thumbnail and len(processed) != 1:
            processed.append(image.resize((self._tile_size, self._tile_size)))

        return [self._transform(img) for img in processed]

    def _augment_tiling(self, tiling: tuple[int, int]) -> tuple[int, int]:
        """Randomly adjust tiling by +/-1 in one dimension."""
        if random.random() < 0.65:
            # Decrease
            if tiling[0] == 1 and tiling[1] == 1:
                return tiling
            elif tiling[0] == 1:
                return (tiling[0], tiling[1] - 1)
            elif tiling[1] == 1:
                return (tiling[0] - 1, tiling[1])
            else:
                return (
                    (tiling[0] - 1, tiling[1])
                    if random.random() < 0.5
                    else (tiling[0], tiling[1] - 1)
                )
        else:
            # Increase
            nt = tiling[0] * tiling[1]
            if nt < self._max_num_tiles:
                t0 = (tiling[0] + 1, tiling[1])
                t1 = (tiling[0], tiling[1] + 1)
                if t0[0] * t0[1] > self._max_num_tiles and t1[0] * t1[1] > self._max_num_tiles:
                    return tiling
                elif t0[0] * t0[1] > self._max_num_tiles:
                    return t1
                elif t1[0] * t1[1] > self._max_num_tiles:
                    return t0
                else:
                    return t0 if random.random() < 0.5 else t1
            return tiling


# ---------------------------------------------------------------------------
# Strategy 3: Dynamic resolution — variable patches per image
# ---------------------------------------------------------------------------
@dataclass
class DynamicResolutionParams(ImageTilingParams):
    patch_size: tuple[int, int] = (1, 1)


class DynamicResolutionImageTilingStrategy(ImageTilingStrategy):
    """Resize images to variable resolution that optimizes patch count within a budget."""

    def __init__(
        self,
        vision_model_type: str,
        min_num_patches: int,
        patch_size: int,
        get_num_embeddings: Callable[[int, int], int],
        factor_max: float = 1.0,
        pixel_shuffle: bool = False,
        min_side: int | None = None,
        conv_merging: bool = False,
        use_thumbnail: bool = False,
        thumbnail_size: int = 448,
        thumbnail_area_threshold: float = 0.8,
        max_num_patches: int = 0,
        apply_data_augment: bool = False,
    ):
        self._vision_model_type = vision_model_type
        self._min_num_patches = min_num_patches
        self._max_num_patches = max_num_patches if max_num_patches > 0 else float("inf")
        self._patch_size = patch_size
        self._get_num_embeddings = get_num_embeddings
        self._factor_max = factor_max
        self._pixel_shuffle = pixel_shuffle
        self._min_side = min_side
        self._conv_merging = conv_merging
        self._use_thumbnail = use_thumbnail
        self._thumbnail_size = thumbnail_size
        self._thumbnail_area_threshold = thumbnail_area_threshold
        self._apply_data_augment = apply_data_augment

        pixel_mean, pixel_std = pixel_statistics[self._vision_model_type]
        self._transform = T.Compose(
            [
                T.Lambda(lambda img: img.convert("RGB") if img.mode != "RGB" else img),
                T.ToTensor(),
                T.Normalize(mean=pixel_mean, std=pixel_std),
            ]
        )

    def _process_single(
        self,
        ref: ImageRef,
        num_tokens_available: int,
        data_augment: bool = False,
        tiling_augment_prob: float = 0.4,
    ) -> tuple[DynamicResolutionParams, int]:
        """Compute dynamic resolution params for a single image."""
        orig_w, orig_h = ref.width, ref.height
        cur_budget = num_tokens_available

        closest_ph = round(orig_h / self._patch_size + 0.5)
        closest_pw = round(orig_w / self._patch_size + 0.5)
        patches = closest_ph * closest_pw

        factor = min(math.sqrt(cur_budget / patches), self._factor_max)
        tph = math.floor(factor * closest_ph)
        tpw = math.floor(factor * closest_pw)

        # Enforce minimum patches
        if cur_budget > self._min_num_patches and tph * tpw < self._min_num_patches:
            up = math.sqrt(self._min_num_patches / (tph * tpw))
            tph = math.ceil(up * tph)
            tpw = math.ceil(up * tpw)

        # Enforce minimum side constraint
        if self._min_side is not None and min(tpw, tph) * self._patch_size < self._min_side:
            if tpw <= tph:
                up = self._min_side / (tpw * self._patch_size)
                new_ph = math.ceil(up * tph)
                new_pw = math.ceil(up * tpw)
                if new_ph * new_pw > cur_budget:
                    if max(cur_budget // new_pw, 1) * self._patch_size < self._min_side:
                        up2 = math.sqrt(cur_budget / (tph * tpw))
                        tph = math.floor(up2 * tph)
                        tpw = math.floor(up2 * tpw)
                    tpw = new_pw
                    tph = max(cur_budget // new_pw, 1)
                else:
                    tph, tpw = new_ph, new_pw
            else:
                up = self._min_side / (tph * self._patch_size)
                new_ph = math.ceil(up * tph)
                new_pw = math.ceil(up * tpw)
                if new_ph * new_pw > cur_budget:
                    if max(cur_budget // new_ph, 1) * self._patch_size < self._min_side:
                        up2 = math.sqrt(cur_budget / (tph * tpw))
                        tph = math.floor(up2 * tph)
                        tpw = math.floor(up2 * tpw)
                    else:
                        tph = new_ph
                        tpw = max(cur_budget // new_ph, 1)
                else:
                    tph, tpw = new_ph, new_pw

        # Round for pixel_shuffle / conv_merging compatibility
        if self._pixel_shuffle or self._conv_merging:
            div = 4 if (self._pixel_shuffle and self._conv_merging) else 2
            rem_h = tph % div
            if rem_h != 0:
                inc_h = div - rem_h
                if (tph + inc_h) * tpw <= cur_budget:
                    tph += inc_h
                else:
                    tph = max(div, tph - rem_h)
            rem_w = tpw % div
            if rem_w != 0:
                inc_w = div - rem_w
                if tph * (tpw + inc_w) <= cur_budget:
                    tpw += inc_w
                else:
                    tpw = max(div, tpw - rem_w)

        # Data augmentation on resolution
        if data_augment and self._apply_data_augment and random.random() < tiling_augment_prob:
            min_one_side = 32
            if random.random() < 0.5:
                if tpw > min_one_side and tph > min_one_side:
                    if random.random() < 0.5:
                        tpw -= min_one_side
                    else:
                        tph -= min_one_side
                elif tpw > min_one_side:
                    tpw -= min_one_side
                elif tph > min_one_side:
                    tph -= min_one_side
            else:
                if tpw * tph < cur_budget:
                    if random.random() < 0.5:
                        tpw += min_one_side
                    else:
                        tph += min_one_side

        num_embeddings = self._get_num_embeddings(
            tpw * self._patch_size, tph * self._patch_size
        )
        token_count = tpw * tph
        num_tiles = 1

        if self._use_thumbnail:
            resized_area = (tpw * self._patch_size) * (tph * self._patch_size)
            thumbnail_area = self._thumbnail_size * self._thumbnail_size
            if resized_area / thumbnail_area < self._thumbnail_area_threshold:
                num_tiles += 1
                num_embeddings += self._get_num_embeddings(
                    self._thumbnail_size, self._thumbnail_size
                )
                ts_patches = self._thumbnail_size // self._patch_size
                token_count += ts_patches * ts_patches

        return (
            DynamicResolutionParams(
                image_ref=ref,
                num_tiles=num_tiles,
                num_embeddings=num_embeddings,
                patch_size=(tpw, tph),
            ),
            token_count,
        )

    def compute_params(
        self,
        image_refs: list[ImageRef],
        num_tokens_available: int | None = None,
        max_num_tiles: int | None = None,
        data_augment: bool = False,
        **kwargs,
    ) -> list[DynamicResolutionParams]:
        budget = num_tokens_available
        if budget is not None:
            budget = budget * (4 if self._pixel_shuffle else 1) * (4 if self._conv_merging else 1)
            budget = max(budget, self._min_num_patches * len(image_refs))

        per_media_budget = [
            max(min(budget, self._max_num_patches), self._min_num_patches)
            for _ in image_refs
        ] if budget is not None else [self._max_num_patches] * len(image_refs)

        for _ in range(10):
            params = []
            token_counts = []
            for ref, media_budget in zip(image_refs, per_media_budget):
                p, tc = self._process_single(ref, media_budget, data_augment=data_augment)
                params.append(p)
                token_counts.append(tc)

            total = sum(token_counts)
            if budget is None or total <= budget:
                return params

            scaling = budget / total
            new_budgets = [
                max(self._min_num_patches, int(tc * scaling))
                for tc in token_counts
            ]
            if all(nb >= ob for nb, ob in zip(new_budgets, per_media_budget)):
                per_media_budget = [self._min_num_patches] * len(image_refs)
            else:
                per_media_budget = new_budgets

        return params

    def apply_params(
        self, params: ImageTilingParams, **kwargs
    ) -> list[torch.Tensor]:
        assert isinstance(params, DynamicResolutionParams)
        resized = params.image_ref.data.resize(
            (
                params.patch_size[0] * self._patch_size,
                params.patch_size[1] * self._patch_size,
            )
        )
        images = [resized]
        if self._use_thumbnail:
            resized_area = resized.size[0] * resized.size[1]
            thumb_area = self._thumbnail_size * self._thumbnail_size
            if resized_area / thumb_area < self._thumbnail_area_threshold:
                images.append(
                    params.image_ref.data.resize(
                        (self._thumbnail_size, self._thumbnail_size)
                    )
                )
        return [self._transform(img) for img in images]

    def stack(
        self, images: list[torch.Tensor]
    ) -> tuple[
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor | None,
    ]:
        if not images:
            return None, None, None, None

        import einops

        imgs_sizes = torch.tensor(
            [[img.shape[1], img.shape[2]] for img in images], dtype=torch.int32
        )

        def rearrange_img(x):
            py = x.shape[-2] // self._patch_size
            px = x.shape[-1] // self._patch_size
            return einops.rearrange(
                x,
                "c (py yy) (px xx) -> (py px) (c yy xx)",
                py=py, yy=self._patch_size, px=px, xx=self._patch_size,
            )

        imgs = [rearrange_img(img) for img in images]
        current_length = 0
        max_length = 0
        vision_cu_lengths = [0]
        for img in imgs:
            max_length = max(max_length, img.shape[0])
            current_length += img.shape[0]
            vision_cu_lengths.append(current_length)

        return (
            torch.cat(imgs, dim=0).unsqueeze(0),
            imgs_sizes,
            torch.tensor(vision_cu_lengths, dtype=torch.int32),
            torch.tensor(max_length, dtype=torch.int32),
        )


# ---------------------------------------------------------------------------
# Strategy 4: Match tiling + dynamic resolution
# ---------------------------------------------------------------------------
@dataclass
class MatchTilingDynamicResolutionParams(ImageTilingParams):
    tiling: tuple[int, int] = (1, 1)


class MatchTilingDynamicResolutionStrategy(ImageTilingStrategy):
    """Use tiling logic for aspect ratio, but process as single dynamic-resolution image."""

    def __init__(
        self,
        vision_model_type: str,
        tile_size: int,
        use_thumbnail: bool,
        min_num_tiles: int,
        max_num_tiles: int,
        embeddings_per_tile: int,
        patch_size: int,
        get_num_embeddings: Callable[[int, int], int],
        find_closest_aspect_ratio_fn=find_closest_aspect_ratio,
        pixel_shuffle: bool = False,
        conv_merging: bool = False,
        tile_degradation_map: dict[int, int] | None = None,
        enable_tile_degradation: bool = True,
    ):
        self._vision_model_type = vision_model_type
        self._tile_size = tile_size
        self._use_thumbnail = use_thumbnail
        self._min_num_tiles = min_num_tiles
        self._max_num_tiles = max_num_tiles
        self._embeddings_per_tile = embeddings_per_tile
        self._patch_size = patch_size
        self._get_num_embeddings = get_num_embeddings
        self._find_closest_aspect_ratio_fn = find_closest_aspect_ratio_fn
        self._pixel_shuffle = pixel_shuffle
        self._conv_merging = conv_merging
        self._enable_tile_degradation = enable_tile_degradation
        self._tile_degradation_map = tile_degradation_map or {12: 8, 8: 6, 6: 4, 4: 2, 2: 1}

        self.target_ratios = {
            mnt: sorted(
                set(
                    (x, y)
                    for n in range(self._min_num_tiles, mnt + 1)
                    for x in range(1, n + 1)
                    for y in range(1, n + 1)
                    if x * y <= mnt and x * y >= self._min_num_tiles
                ),
                key=lambda x: x[0] * x[1],
            )
            for mnt in range(self._min_num_tiles, self._max_num_tiles + 1)
        }

        pixel_mean, pixel_std = pixel_statistics[self._vision_model_type]
        self._transform = T.Compose(
            [
                T.Lambda(lambda img: img.convert("RGB") if img.mode != "RGB" else img),
                T.ToTensor(),
                T.Normalize(mean=pixel_mean, std=pixel_std),
            ]
        )

    def compute_params(
        self,
        image_refs: list[ImageRef],
        num_tokens_available: int | None = None,
        max_num_tiles: int | None = None,
        **kwargs,
    ) -> list[MatchTilingDynamicResolutionParams]:
        effective_max = min(
            max_num_tiles if max_num_tiles is not None else self._max_num_tiles,
            self._max_num_tiles,
        )
        max_to_use = effective_max

        while True:
            params = []
            total_emb = 0
            for ref in image_refs:
                aspect_ratio = ref.width / ref.height
                target_ratios = self.target_ratios.get(max_to_use)
                if target_ratios is None:
                    self.target_ratios[max_to_use] = sorted(
                        set(
                            (x, y)
                            for n in range(self._min_num_tiles, max_to_use + 1)
                            for x in range(1, n + 1)
                            for y in range(1, n + 1)
                            if x * y <= max_to_use and x * y >= self._min_num_tiles
                        ),
                        key=lambda x: x[0] * x[1],
                    )
                    target_ratios = self.target_ratios[max_to_use]

                tiling = self._find_closest_aspect_ratio_fn(
                    aspect_ratio, target_ratios, ref.width, ref.height, self._tile_size
                )
                tw = self._tile_size * tiling[0]
                th = self._tile_size * tiling[1]
                num_emb = self._get_num_embeddings(tw, th)
                num_tiles = 1
                blocks = tiling[0] * tiling[1]
                if self._use_thumbnail and blocks != 1:
                    num_tiles += 1
                    num_emb += self._get_num_embeddings(self._tile_size, self._tile_size)

                params.append(
                    MatchTilingDynamicResolutionParams(
                        image_ref=ref,
                        num_tiles=num_tiles,
                        num_embeddings=num_emb,
                        tiling=tiling,
                    )
                )
                total_emb += num_emb

            if not self._enable_tile_degradation or max_to_use == 1 or num_tokens_available is None:
                break
            if total_emb > num_tokens_available:
                if max_to_use in self._tile_degradation_map:
                    max_to_use = self._tile_degradation_map[max_to_use]
                else:
                    break
            else:
                break

        return params

    def apply_params(
        self, params: ImageTilingParams, **kwargs
    ) -> list[torch.Tensor]:
        assert isinstance(params, MatchTilingDynamicResolutionParams)
        image = params.image_ref.data
        tw = self._tile_size * params.tiling[0]
        th = self._tile_size * params.tiling[1]
        resized = image.resize((tw, th))
        images = [resized]
        blocks = params.tiling[0] * params.tiling[1]
        if self._use_thumbnail and blocks != 1:
            images.append(image.resize((self._tile_size, self._tile_size)))
        return [self._transform(img) for img in images]

    def stack(
        self, images: list[torch.Tensor]
    ) -> tuple[
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor | None,
    ]:
        if not images:
            return None, None, None, None

        import einops

        imgs_sizes = torch.tensor(
            [[img.shape[1], img.shape[2]] for img in images], dtype=torch.int32
        )

        def rearrange_img(x):
            py = x.shape[-2] // self._patch_size
            px = x.shape[-1] // self._patch_size
            return einops.rearrange(
                x,
                "c (py yy) (px xx) -> (py px) (c yy xx)",
                py=py, yy=self._patch_size, px=px, xx=self._patch_size,
            )

        imgs = [rearrange_img(img) for img in images]
        current_length = 0
        max_length = 0
        vision_cu_lengths = [0]
        for img in imgs:
            max_length = max(max_length, img.shape[0])
            current_length += img.shape[0]
            vision_cu_lengths.append(current_length)

        return (
            torch.cat(imgs, dim=0).unsqueeze(0),
            imgs_sizes,
            torch.tensor(vision_cu_lengths, dtype=torch.int32),
            torch.tensor(max_length, dtype=torch.int32),
        )


# ---------------------------------------------------------------------------
# Strategy 5: Masked tiling — per-tile block-diagonal attention
# ---------------------------------------------------------------------------
@dataclass
class MaskedTilingDynamicResolutionParams(ImageTilingParams):
    tiling: tuple[int, int] = (1, 1)


class MaskedTilingDynamicResolutionStrategy(MatchTilingDynamicResolutionStrategy):
    """Like MatchTiling, but each tile is emitted separately for block-diagonal attention."""

    def apply_params(
        self, params: ImageTilingParams, **kwargs
    ) -> list[torch.Tensor]:
        assert isinstance(params, MaskedTilingDynamicResolutionParams)
        image = params.image_ref.data
        nx, ny = params.tiling
        tw = self._tile_size * nx
        th = self._tile_size * ny
        resized = image.resize((tw, th))

        tiles = []
        for j in range(ny):
            for i in range(nx):
                box = (
                    i * self._tile_size,
                    j * self._tile_size,
                    (i + 1) * self._tile_size,
                    (j + 1) * self._tile_size,
                )
                tiles.append(resized.crop(box))

        if self._use_thumbnail and (nx * ny) != 1:
            tiles.append(image.resize((self._tile_size, self._tile_size)))

        return [self._transform(img) for img in tiles]

    def compute_params(
        self,
        image_refs: list[ImageRef],
        num_tokens_available: int | None = None,
        max_num_tiles: int | None = None,
        data_augment: bool = False,
        tiling_augment_prob: float = 0.4,
        **kwargs,
    ) -> list[MaskedTilingDynamicResolutionParams]:
        effective_max = min(
            max_num_tiles if max_num_tiles is not None else self._max_num_tiles,
            self._max_num_tiles,
        )
        max_to_use = effective_max

        while True:
            params = []
            total_emb = 0
            for ref in image_refs:
                aspect_ratio = ref.width / ref.height
                target_ratios = self.target_ratios.get(max_to_use)
                if target_ratios is None:
                    self.target_ratios[max_to_use] = sorted(
                        set(
                            (x, y)
                            for n in range(self._min_num_tiles, max_to_use + 1)
                            for x in range(1, n + 1)
                            for y in range(1, n + 1)
                            if x * y <= max_to_use and x * y >= self._min_num_tiles
                        ),
                        key=lambda x: x[0] * x[1],
                    )
                    target_ratios = self.target_ratios[max_to_use]

                tiling = self._find_closest_aspect_ratio_fn(
                    aspect_ratio, target_ratios, ref.width, ref.height, self._tile_size
                )
                blocks = tiling[0] * tiling[1]
                per_tile_emb = self._get_num_embeddings(self._tile_size, self._tile_size)
                num_emb = blocks * per_tile_emb
                num_tiles = blocks
                if self._use_thumbnail and blocks != 1:
                    num_tiles += 1
                    num_emb += per_tile_emb

                params.append(
                    MaskedTilingDynamicResolutionParams(
                        image_ref=ref,
                        num_tiles=num_tiles,
                        num_embeddings=num_emb,
                        tiling=tiling,
                    )
                )
                total_emb += num_emb

            if not self._enable_tile_degradation or max_to_use == 1 or num_tokens_available is None:
                break
            if total_emb > num_tokens_available:
                if max_to_use in self._tile_degradation_map:
                    max_to_use = self._tile_degradation_map[max_to_use]
                else:
                    break
            else:
                break

        return params


# ---------------------------------------------------------------------------
# Strategy 6: Tile degradation wrapper
# ---------------------------------------------------------------------------
class TileDegradationStrategy(ImageTilingStrategy):
    """Wraps an image strategy with degradation: reduce tiles when over budget."""

    def __init__(
        self,
        image_strategy: ImageTilingStrategy,
        embeddings_per_tile: int,
        max_num_tiles: int,
        tile_degradation_map: dict[int, int] | None = None,
    ):
        self._image_strategy = image_strategy
        self._embeddings_per_tile = embeddings_per_tile
        self._max_num_tiles = max_num_tiles
        self._tile_degradation_map = tile_degradation_map or {
            12: 8, 8: 6, 6: 4, 4: 2, 2: 1,
        }

    def compute_params(
        self,
        image_refs: list[ImageRef],
        num_tokens_available: int | None = None,
        max_num_tiles: int | None = None,
        **kwargs,
    ) -> list[ImageTilingParams]:
        effective_max = max_num_tiles if max_num_tiles is not None else self._max_num_tiles
        max_to_use = effective_max

        while True:
            params = self._image_strategy.compute_params(
                image_refs,
                max_to_use * self._embeddings_per_tile,
                max_to_use,
                **kwargs,
            )
            if max_to_use == 1 or num_tokens_available is None:
                break
            total_tiles = sum(p.num_tiles for p in params)
            if total_tiles * self._embeddings_per_tile > num_tokens_available:
                if max_to_use in self._tile_degradation_map:
                    max_to_use = self._tile_degradation_map[max_to_use]
                else:
                    break
            else:
                break
        return params

    def apply_params(
        self, params: ImageTilingParams, **kwargs
    ) -> list[torch.Tensor]:
        return self._image_strategy.apply_params(params, **kwargs)

    def stack(
        self, images: list[torch.Tensor]
    ) -> tuple[
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor | None,
    ]:
        return self._image_strategy.stack(images)


# ---------------------------------------------------------------------------
# Factory: build strategy from VisionConfig
# ---------------------------------------------------------------------------
def create_image_tiling_strategy(config) -> ImageTilingStrategy:
    """Create the appropriate tiling strategy from a VisionConfig.

    Args:
        config: A VisionConfig instance.

    Returns:
        The configured ImageTilingStrategy.
    """
    from megatron.energon.task_encoder.multimodal.config import VisionConfig

    assert isinstance(config, VisionConfig)
    assert config.img_h == config.img_w, "img_h and img_w must be the same"

    def _get_num_emb(width: int, height: int) -> int:
        return get_num_image_embeddings(
            img_h=height,
            img_w=width,
            patch_dim=config.patch_dim,
            class_token_len=config.class_token_len,
            disable_vision_class_token=config.disable_vision_class_token,
            pixel_shuffle=config.pixel_shuffle,
            conv_merging=config.conv_merging,
            use_tile_tags=config.use_tile_tags,
            max_num_tiles=config.max_num_tiles,
            use_image_break_token=config.use_image_break_token,
        )

    num_emb_per_tile = _get_num_emb(config.img_w, config.img_h)

    find_ar_fn = (
        find_closest_area_weighted_aspect_ratio
        if config.use_area_weighted_aspect_ratio
        else find_closest_aspect_ratio
    )

    if config.dynamic_resolution:
        if config.masked_tiling_dynamic_resolution:
            return MaskedTilingDynamicResolutionStrategy(
                vision_model_type=config.vision_model_type,
                tile_size=config.img_h,
                use_thumbnail=config.use_thumbnail,
                min_num_tiles=config.min_num_tiles,
                max_num_tiles=config.max_num_tiles,
                embeddings_per_tile=num_emb_per_tile,
                patch_size=config.patch_dim,
                get_num_embeddings=_get_num_emb,
                find_closest_aspect_ratio_fn=find_ar_fn,
                pixel_shuffle=config.pixel_shuffle,
                conv_merging=config.conv_merging,
            )
        elif config.match_tiling_dynamic_resolution:
            return MatchTilingDynamicResolutionStrategy(
                vision_model_type=config.vision_model_type,
                tile_size=config.img_h,
                use_thumbnail=config.use_thumbnail,
                min_num_tiles=config.min_num_tiles,
                max_num_tiles=config.max_num_tiles,
                embeddings_per_tile=num_emb_per_tile,
                patch_size=config.patch_dim,
                get_num_embeddings=_get_num_emb,
                find_closest_aspect_ratio_fn=find_ar_fn,
                pixel_shuffle=config.pixel_shuffle,
                conv_merging=config.conv_merging,
            )
        else:
            return DynamicResolutionImageTilingStrategy(
                vision_model_type=config.vision_model_type,
                min_num_patches=config.dynamic_resolution_min_patches,
                patch_size=config.patch_dim,
                get_num_embeddings=_get_num_emb,
                pixel_shuffle=config.pixel_shuffle,
                min_side=config.dynamic_resolution_min_side,
                conv_merging=config.conv_merging,
                use_thumbnail=config.use_thumbnail,
                thumbnail_size=config.img_h,
                thumbnail_area_threshold=config.thumbnail_area_threshold,
                max_num_patches=config.dynamic_resolution_max_patches,
                apply_data_augment=config.apply_data_augment,
            )
    else:
        if config.use_tiling:
            image_strategy = ImageTilingStrategyV1(
                vision_model_type=config.vision_model_type,
                tile_size=config.img_h,
                use_thumbnail=config.use_thumbnail,
                min_num_tiles=config.min_num_tiles,
                max_num_tiles=config.max_num_tiles,
                embeddings_per_tile=num_emb_per_tile,
                find_closest_aspect_ratio_fn=find_ar_fn,
            )
        else:
            image_strategy = NoTilingStrategy(
                vision_model_type=config.vision_model_type,
                embeddings_per_image=num_emb_per_tile,
                target_width=config.img_w,
                target_height=config.img_h,
            )
        return TileDegradationStrategy(
            image_strategy=image_strategy,
            embeddings_per_tile=num_emb_per_tile,
            max_num_tiles=config.max_num_tiles,
        )
