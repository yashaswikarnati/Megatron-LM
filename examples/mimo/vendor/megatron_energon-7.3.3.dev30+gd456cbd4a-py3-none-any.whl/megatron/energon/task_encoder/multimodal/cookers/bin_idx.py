# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Cooker for bin-idx pre-tokenized text → MultiModalSample (text-only, no images)."""

import torch

from megatron.energon.task_encoder.base import stateless
from megatron.energon.task_encoder.cooking import basic_sample_keys, cooker
from megatron.energon.task_encoder.multimodal.sample_types import MultiModalSample


@stateless
@cooker()
def cook_bin_idx_multimodal(sample: dict) -> MultiModalSample:
    """Convert a raw bin-idx sample to a MultiModalSample with pre-tokenized tokens."""
    tokens = sample["tokens"]  # np.ndarray(int32), may be read-only
    return MultiModalSample(
        **basic_sample_keys(sample),
        tokens=torch.tensor(tokens, dtype=torch.long),
        images=[],
    )
