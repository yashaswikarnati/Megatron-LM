# Copyright (c) 2026, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Cooker for OmniCorpus-CC interleaved image+text documents.

Expected webdataset format per sample:
    {key}.json_image_text  — JSON list of segments:
        [{"type": "text", "text": "..."}, {"type": "image", "image": "000000001"}, ...]
    {key}.images           — pickle'd dict mapping image IDs to JPEG bytes:
        {"000000001": b'\\xff\\xd8...', ...}
    {key}.metadata.json    — {"doc_id": "...", "stats": {...}}
    {key}.general_metadata.pkl — quality scores, domain, url, etc.

``decoder: null`` is NOT required — the non-standard extensions (``.json_image_text``,
``.images``) are left as raw bytes by the default webdataset decoder.  The cooker
handles both bytes and pre-decoded forms via ``isinstance`` checks.
"""

import io
import json as _json
import pickle as _pickle

from PIL import Image

from megatron.energon.task_encoder.base import stateless
from megatron.energon.task_encoder.cooking import basic_sample_keys, cooker
from megatron.energon.task_encoder.multimodal.sample_types import (
    ImageRef,
    MultiModalSample,
)

IMAGE_TAG = "<image>"


@stateless
@cooker(need_cache=False)
def cook_omnicorpus(sample: dict) -> MultiModalSample:
    # Decode json_image_text (raw bytes -> list of segments)
    raw_jit = sample["json_image_text"]
    if isinstance(raw_jit, bytes):
        raw_jit = _json.loads(raw_jit)

    # Decode images (raw bytes -> dict of image_id -> JPEG bytes)
    raw_imgs = sample.get("images", b"")
    if isinstance(raw_imgs, bytes) and len(raw_imgs) > 0:
        img_dict = _pickle.loads(raw_imgs)
    else:
        img_dict = {}

    # Walk segments, build text with <image> tags and collect ImageRefs
    parts = []
    image_refs = []

    for segment in raw_jit:
        seg_type = segment.get("type")
        if seg_type == "text":
            parts.append(segment["text"])
        elif seg_type == "image":
            img_id = segment["image"]
            if img_id in img_dict:
                img_bytes = img_dict[img_id]
                try:
                    pil_img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
                    w, h = pil_img.size
                    image_refs.append(ImageRef(data=pil_img, width=w, height=h))
                    parts.append(IMAGE_TAG)
                except Exception:
                    # Corrupt/invalid image data (e.g. HTML error pages) — skip
                    pass

    text = "".join(parts)

    return MultiModalSample(
        **basic_sample_keys(sample),
        text=text,
        images=image_refs,
    )
