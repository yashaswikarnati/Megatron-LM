# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""MultiModalPackingEncoder — packs interleaved image+text into fixed-length sequences.

No megatron.core or megatron.training dependencies. Configuration is fully
explicit via VisionConfig, PackingConfig, and a tokenizer that satisfies
TokenizerProtocol.

Follows the same pipeline contract as TextPackingEncoder:
    MultiModalSample → PreEncodedSample → PackedSample → dict

Cookers:
    - cook_bin_idx_multimodal: pre-tokenized text (bin-idx), no images.
    - cook_image_caption: webdataset (jpg+txt) image-caption pairs.
    - cook_interleaved: webdataset/JSONL interleaved image+text.
    - cook_conversation_plain: SFT conversation formatted as plain text.
"""

import random
from typing import Generator, List

import torch

from megatron.energon.task_encoder.base import TaskEncoder, stateless
from megatron.energon.task_encoder.cooking import Cooker
from megatron.energon.task_encoder.knapsack import greedy_knapsack
from megatron.energon.task_encoder.multimodal.config import (
    PackingConfig,
    TokenizerProtocol,
    VisionConfig,
)
from megatron.energon.task_encoder.multimodal.cookers.bin_idx import (
    cook_bin_idx_multimodal,
)
from megatron.energon.task_encoder.multimodal.cookers.conversation import (
    cook_conversation_plain,
)
from megatron.energon.task_encoder.multimodal.cookers.image_caption import (
    cook_image_caption,
)
from megatron.energon.task_encoder.multimodal.cookers.interleaved import (
    cook_interleaved,
)
from megatron.energon.task_encoder.multimodal.cookers.nvmint_segments import (
    cook_nvmint_segments,
)
from megatron.energon.task_encoder.multimodal.cookers.nvmint_imgcaption import (
    cook_nvmint_imgcaption,
)
from megatron.energon.task_encoder.multimodal.cookers.omni_corpus import (
    cook_omnicorpus,
)
from megatron.energon.task_encoder.multimodal.cookers.pretraining_conversation import (
    cook_vlm_conversation,
)
from megatron.energon.task_encoder.multimodal.image_tiling import (
    ImageTilingStrategy,
    create_image_tiling_strategy,
)
from megatron.energon.task_encoder.multimodal.sample_types import (
    MultiModalSample,
    PackedSample,
    PreEncodedSample,
)

IMAGE_TAG = "<image>"


class MultiModalPackingEncoder(
    TaskEncoder[MultiModalSample, PreEncodedSample, PackedSample, dict]
):
    """Packs multimodal (image+text) and text-only documents into fixed-length sequences.

    This encoder handles four data formats via cookers:
        - Pre-tokenized text (bin-idx)
        - Image-caption pairs (webdataset)
        - Interleaved image+text documents (webdataset/JSONL)
        - SFT conversations as plain text (webdataset/JSONL)

    All configuration is explicit — no global state, no ``get_args()``.

    Args:
        vision_config: Vision encoder configuration (patch size, tiling, etc.).
        packing_config: Sequence length, packing strategy, pad/ignore tokens.
        tokenizer: Any tokenizer satisfying TokenizerProtocol (e.g. HuggingFace).
    """

    cookers = [
        Cooker(cook_bin_idx_multimodal, has_subflavors={"cook": "bin_idx"}),
        Cooker(cook_image_caption, has_subflavors={"cook": "image_caption"}),
        Cooker(cook_interleaved, has_subflavors={"cook": "interleaved"}),
        Cooker(cook_conversation_plain, has_subflavors={"cook": "conversation"}),
        Cooker(cook_omnicorpus, has_subflavors={"cook": "omnicorpus"}),
        Cooker(cook_nvmint_segments, has_subflavors={"cook": "nvmint_segments"}),
        Cooker(cook_nvmint_imgcaption, has_subflavors={"cook": "nvmint_imgcaption"}),
        Cooker(cook_vlm_conversation, has_subflavors={"cook": "pretraining_conversation"}),
    ]

    def __init__(
        self,
        vision_config: VisionConfig,
        packing_config: PackingConfig,
        tokenizer: TokenizerProtocol,
    ):
        super().__init__()
        self.vision_config = vision_config
        self.packing_config = packing_config
        self.tokenizer = tokenizer
        self.tiling_strategy: ImageTilingStrategy = create_image_tiling_strategy(
            vision_config
        )

    # ------------------------------------------------------------------
    # Stage 1: preencode — tokenize text, compute image tiling params
    # ------------------------------------------------------------------
    @stateless
    def preencode_sample(self, sample: MultiModalSample) -> PreEncodedSample:
        cfg = self.packing_config

        if sample.tokens is not None:
            # Pre-tokenized path (bin-idx): no images expected
            tokens = sample.tokens
            labels = torch.full_like(tokens, cfg.ignore_index)
            labels[:-1] = tokens[1:]
            return PreEncodedSample(
                tokens=tokens,
                labels=labels,
                image_params=[],
                total_len=len(tokens),
            )

        # Raw text path: tokenize and insert image token placeholders
        text = sample.text
        images = sample.images

        # Split text on <image> tags and tokenize each segment
        segments = text.split(IMAGE_TAG)
        all_token_ids = []
        for i, seg in enumerate(segments):
            if seg:
                seg_ids = self.tokenizer.encode(seg, add_special_tokens=(i == 0))
                all_token_ids.extend(seg_ids)
            if i < len(segments) - 1:
                # Insert a single placeholder token for this image
                all_token_ids.append(cfg.image_token_id)

        tokens_tensor = torch.tensor(all_token_ids, dtype=torch.long)

        # Compute image tiling parameters
        image_params = []
        if images:
            # Token budget for images: seq_length - text_tokens
            text_token_count = sum(1 for t in all_token_ids if t != cfg.image_token_id)
            token_budget = max(cfg.seq_length - text_token_count, len(images))
            tiling_params = self.tiling_strategy.compute_params(
                images, token_budget
            )
            image_params = tiling_params

        # Compute total sequence length:
        # text tokens + sum(image_embeddings) - num_image_placeholders
        total_image_tokens = sum(p.num_embeddings for p in image_params)
        num_placeholders = sum(1 for t in all_token_ids if t == cfg.image_token_id)
        total_len = len(all_token_ids) + total_image_tokens - num_placeholders

        # Build labels: shift tokens by 1 for causal LM
        labels = torch.full_like(tokens_tensor, cfg.ignore_index)
        labels[:-1] = tokens_tensor[1:]

        # Truncate if needed
        if total_len > cfg.seq_length:
            # For truncation, we need to cut text tokens (not image tokens).
            # Keep all image placeholders and their embeddings, truncate text.
            max_text = cfg.seq_length - total_image_tokens + num_placeholders
            if max_text > 0:
                tokens_tensor = tokens_tensor[:max_text]
                labels = labels[:max_text]
            else:
                # Extreme case: images alone exceed budget. Truncate to seq_length.
                tokens_tensor = tokens_tensor[: cfg.seq_length]
                labels = labels[: cfg.seq_length]

            # Trim image_params to match remaining placeholders
            remaining_placeholders = (tokens_tensor == cfg.image_token_id).sum().item()
            image_params = image_params[:remaining_placeholders]

            # Recompute total_len after truncation
            total_image_tokens = sum(p.num_embeddings for p in image_params)
            total_len = len(tokens_tensor) - remaining_placeholders + total_image_tokens

        return PreEncodedSample(
            tokens=tokens_tensor,
            labels=labels,
            image_params=image_params,
            total_len=total_len,
        )

    # ------------------------------------------------------------------
    # Stage 2: split for packing — configurable strategy
    # ------------------------------------------------------------------
    @stateless
    def split_sample_for_packing(
        self, sample: PreEncodedSample
    ) -> Generator[PreEncodedSample, None, None]:
        max_len = self.packing_config.seq_length

        if sample.total_len <= max_len:
            yield sample
            return

        if self.packing_config.split_strategy == "truncate":
            # Just truncate tokens to fit (image params already computed)
            yield PreEncodedSample(
                tokens=sample.tokens[:max_len],
                labels=sample.labels[:max_len],
                image_params=sample.image_params,
                total_len=min(sample.total_len, max_len),
            )
            return

        # "split" strategy: split at safe boundaries
        if not sample.image_params:
            # Text-only: simple chunking (same as TextPackingEncoder)
            for start in range(0, len(sample.tokens), max_len):
                chunk_tokens = sample.tokens[start : start + max_len]
                chunk_labels = sample.labels[start : start + max_len]
                yield PreEncodedSample(
                    tokens=chunk_tokens,
                    labels=chunk_labels,
                    image_params=[],
                    total_len=len(chunk_tokens),
                )
        else:
            # Has images: find image placeholder positions and split between them
            placeholder_id = self.packing_config.image_token_id
            placeholder_positions = [
                i for i, t in enumerate(sample.tokens.tolist())
                if t == placeholder_id
            ]

            # Build segments: each segment ends after an image's token span
            # For simplicity, yield one chunk per image boundary that fits
            current_start = 0
            current_images = []
            current_text_len = 0
            img_idx = 0

            for pos_idx, pos in enumerate(placeholder_positions):
                img_params = sample.image_params[img_idx] if img_idx < len(sample.image_params) else None
                img_idx += 1
                if img_params is None:
                    continue

                # Text tokens from current_start to pos (exclusive), plus this image
                text_chunk_len = pos - current_start
                img_len = img_params.num_embeddings
                chunk_total = current_text_len + text_chunk_len + img_len

                if chunk_total > max_len and current_images:
                    # Flush current chunk
                    end = placeholder_positions[pos_idx - 1] + 1 if pos_idx > 0 else pos
                    chunk_tokens = sample.tokens[current_start:end]
                    chunk_labels = sample.labels[current_start:end]
                    # current_text_len includes placeholders (+1 each), so subtract them
                    # to get the expanded length: text_without_placeholders + image_embeddings
                    num_img = len(current_images)
                    yield PreEncodedSample(
                        tokens=chunk_tokens,
                        labels=chunk_labels,
                        image_params=list(current_images),
                        total_len=current_text_len - num_img + sum(
                            p.num_embeddings for p in current_images
                        ),
                    )
                    current_start = end
                    current_images = []
                    current_text_len = 0

                current_images.append(img_params)
                current_text_len += text_chunk_len + 1  # +1 for the placeholder token

            # Yield remaining
            if current_start < len(sample.tokens):
                chunk_tokens = sample.tokens[current_start:]
                chunk_labels = sample.labels[current_start:]
                remaining_total = len(chunk_tokens) + sum(
                    p.num_embeddings for p in current_images
                ) - len(current_images)
                yield PreEncodedSample(
                    tokens=chunk_tokens,
                    labels=chunk_labels,
                    image_params=list(current_images),
                    total_len=remaining_total,
                )

    # ------------------------------------------------------------------
    # Stage 3: select samples to pack (knapsack)
    # ------------------------------------------------------------------
    @stateless
    def select_samples_to_pack(
        self, samples: List[PreEncodedSample]
    ) -> List[List[PreEncodedSample]]:
        lengths = [s.total_len for s in samples]
        packed = greedy_knapsack(lengths, samples, self.packing_config.seq_length)
        random.shuffle(packed)
        return packed

    # ------------------------------------------------------------------
    # Stage 4: postencode — materialize images, apply tiling transforms
    # ------------------------------------------------------------------
    @stateless
    def postencode_sample(self, sample: PreEncodedSample) -> PackedSample:
        image_tensors = []
        num_tiles = []

        for params in sample.image_params:
            tiles = self.tiling_strategy.apply_params(params)
            image_tensors.extend(tiles)
            num_tiles.append(len(tiles))

        return PackedSample(
            tokens=sample.tokens,
            labels=sample.labels,
            images=image_tensors,
            num_tiles=num_tiles,
            cu_lengths=torch.tensor([0, sample.total_len], dtype=torch.int32),
            max_length=sample.total_len,
        )

    # ------------------------------------------------------------------
    # Stage 5: pack selected samples into one PackedSample
    # ------------------------------------------------------------------
    @stateless
    def pack_selected_samples(self, samples: List[PackedSample]) -> PackedSample:
        all_tokens = torch.cat([s.tokens for s in samples])
        all_labels = torch.cat([s.labels for s in samples])

        # Pad to seq_length
        pad_needed = self.packing_config.seq_length - len(all_tokens)
        if pad_needed > 0:
            all_tokens = torch.cat(
                [
                    all_tokens,
                    torch.full(
                        (pad_needed,),
                        self.packing_config.pad_id,
                        dtype=torch.long,
                    ),
                ]
            )
            all_labels = torch.cat(
                [
                    all_labels,
                    torch.full(
                        (pad_needed,),
                        self.packing_config.ignore_index,
                        dtype=torch.long,
                    ),
                ]
            )

        # Merge images and build cumulative lengths
        all_images = []
        all_num_tiles = []
        cu_lengths = [0]
        for s in samples:
            all_images.extend(s.images)
            all_num_tiles.extend(s.num_tiles)
            cu_lengths.append(cu_lengths[-1] + s.cu_lengths[-1].item())

        return PackedSample(
            tokens=all_tokens,
            labels=all_labels,
            images=all_images,
            num_tiles=all_num_tiles,
            cu_lengths=torch.tensor(cu_lengths, dtype=torch.int32),
            max_length=self.packing_config.seq_length,
        )

    # ------------------------------------------------------------------
    # Stage 6: batch
    # ------------------------------------------------------------------
    def batch(self, samples: List[PackedSample]) -> dict:
        batch_size = len(samples)
        seq_len = self.packing_config.seq_length

        # Stack tokens and labels (already padded to seq_length)
        tokens = torch.stack([s.tokens[:seq_len] for s in samples])
        labels = torch.stack([s.labels[:seq_len] for s in samples])

        # Stack images
        all_images = [img for s in samples for img in s.images]
        if all_images:
            imgs, imgs_sizes, vision_cu_lengths, vision_max_lengths = (
                self.tiling_strategy.stack(all_images)
            )
        else:
            imgs = None
            imgs_sizes = None
            vision_cu_lengths = None
            vision_max_lengths = None

        # Num tiles per sample — flatten to a 1-D tensor of per-image tile
        # counts.  For text-only batches (no images) use a single-element
        # dummy so downstream broadcast_data doesn't choke on an empty tensor.
        flat_tiles = [
            t
            for s in samples
            for per_sample in [s.num_tiles]
            for t in (per_sample if isinstance(per_sample, list) else [per_sample])
        ]
        num_tiles = torch.tensor(flat_tiles if flat_tiles else [0], dtype=torch.int32)

        # Cumulative lengths — pad to same length across batch.
        # Normalize: cu_lengths values can exceed seq_len when total_len
        # includes expanded image embeddings but tokens use placeholders.
        # Clamp to [0, seq_len], deduplicate, and ensure [0, ..., seq_len]
        # boundaries so downstream consumers (e.g. Mamba SSM seq_idx) get
        # a valid partition of [0, seq_len].
        fixed_rows = []
        for s in samples:
            row = s.cu_lengths.clone()
            # Strip trailing-zero padding (but keep the leading 0)
            nz = (row != 0).nonzero(as_tuple=True)[0]
            end_idx = nz[-1].item() + 1 if len(nz) > 0 else 1
            active = row[:end_idx]
            # Clamp to [0, seq_len]
            active = active.clamp(0, seq_len)
            # Remove duplicate consecutive values (from clamping)
            keep = torch.ones(len(active), dtype=torch.bool)
            keep[1:] = active[1:] != active[:-1]
            active = active[keep]
            # Ensure starts at 0 and ends at seq_len
            if active[0] != 0:
                active = torch.cat(
                    [torch.tensor([0], dtype=torch.int32), active]
                )
            if active[-1] != seq_len:
                active = torch.cat(
                    [active, torch.tensor([seq_len], dtype=torch.int32)]
                )
            fixed_rows.append(active)

        max_cu = max(len(r) for r in fixed_rows)
        cu_lengths = torch.zeros(batch_size, max_cu, dtype=torch.int32)
        for i, r in enumerate(fixed_rows):
            cu_lengths[i, : len(r)] = r

        # Derive max_lengths: maximum segment length per sample (for
        # PackedSeqParams.max_seqlen_q / max_seqlen_kv).
        # Shape [1, batch_size] so get_batch's `max_lengths[0]` yields [batch_size].
        diffs = cu_lengths[:, 1:] - cu_lengths[:, :-1]
        diffs = diffs.clamp(min=0)
        max_lengths = diffs.max(dim=-1).values.unsqueeze(0)  # [1, batch_size]

        return {
            "tokens": tokens,
            "labels": labels,
            "images": imgs,
            "images_sizes": imgs_sizes,
            "num_tiles": num_tiles,
            "cu_lengths": cu_lengths,
            "max_lengths": max_lengths,
            "vision_cu_lengths": vision_cu_lengths,
            "vision_max_lengths": vision_max_lengths,
        }
