# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Shared image conversion utilities for cookers."""

import io
from typing import Any

import torch
from PIL import Image


def to_pil_image(img_data: Any) -> Image.Image:
    """Convert any supported image format to an RGB PIL Image.

    Handles:
    - PIL Image (returned as-is after RGB conversion)
    - bytes (JPEG/PNG/etc. decoded via PIL)
    - torch.Tensor (C,H,W float tensor → PIL via torchvision)
    - numpy.ndarray (H,W,C uint8 → PIL)
    - file path string (opened via PIL)
    """
    if isinstance(img_data, Image.Image):
        return img_data.convert("RGB")

    if isinstance(img_data, bytes):
        return Image.open(io.BytesIO(img_data)).convert("RGB")

    if isinstance(img_data, torch.Tensor):
        # Energon default decoder produces (C, H, W) float tensors in [0, 1]
        from torchvision.transforms.functional import to_pil_image as _tvf_to_pil

        return _tvf_to_pil(img_data).convert("RGB")

    try:
        import numpy as np

        if isinstance(img_data, np.ndarray):
            return Image.fromarray(img_data).convert("RGB")
    except ImportError:
        pass

    # Fall back to opening as a file path
    return Image.open(img_data).convert("RGB")


def extract_tiff_pages(tiff_data: bytes) -> list[Image.Image]:
    img = Image.open(io.BytesIO(tiff_data))
    pages = []
    try:
        while True:
            pages.append(img.copy().convert("RGB"))
            img.seek(len(pages))
    except EOFError:
        pass
    return pages
