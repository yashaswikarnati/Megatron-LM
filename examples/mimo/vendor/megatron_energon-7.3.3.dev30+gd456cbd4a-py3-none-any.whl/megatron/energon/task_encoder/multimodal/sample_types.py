# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Sample types for the multimodal packing pipeline.

Pipeline:  MultiModalSample → PreEncodedSample → PackedSample → dict
"""

from dataclasses import dataclass, field
from typing import Optional

import torch
from PIL import Image

from megatron.energon.edataclass import edataclass
from megatron.energon.flavors import Sample


# ---------------------------------------------------------------------------
# Cooker output — the common type all cookers produce
# ---------------------------------------------------------------------------
@edataclass
class ImageRef:
    """Reference to an image within a document."""

    #: The image data (PIL Image or lazy-loaded).
    data: Image.Image

    #: Original dimensions (used for tiling computation before loading).
    width: int
    height: int


@edataclass
class MultiModalSample(Sample):
    """Output of all multimodal cookers.

    Either ``text`` (raw string, tokenized by the encoder) or ``tokens``
    (pre-tokenized tensor, e.g. from bin-idx) must be set.
    Images are optional — an empty list means text-only.
    """

    #: Raw text with ``<image>`` placeholders (tokenized by the encoder).
    text: Optional[str] = None

    #: Pre-tokenized document (e.g. from bin-idx). Mutually exclusive with ``text``.
    tokens: Optional[torch.Tensor] = None

    #: Images in document order. Position corresponds to ``<image>`` tags in text,
    #: or is irrelevant for pre-tokenized samples (should be empty).
    images: list[ImageRef] = field(default_factory=list)


# ---------------------------------------------------------------------------
# After preencode — tokenized, tiling computed, media still lazy
# ---------------------------------------------------------------------------
@dataclass
class ImageTilingParams:
    """Computed tiling parameters for one image — media not yet materialized."""

    #: The image reference (still a PIL image or lazy).
    image_ref: ImageRef

    #: Number of tiles this image will be split into.
    num_tiles: int

    #: Total vision embeddings this image will produce.
    num_embeddings: int


@dataclass
class PreEncodedSample:
    """Tokenized sample with tiling parameters computed but images not yet materialized."""

    #: Token IDs with IMAGE_TOKEN placeholders.
    tokens: torch.Tensor

    #: Labels (shifted tokens with IGNORE_INDEX for non-trainable positions).
    labels: torch.Tensor

    #: Tiling parameters per image (in document order).
    image_params: list[ImageTilingParams]

    #: Total sequence length including image embeddings (text tokens + image tokens - placeholders).
    total_len: int


# ---------------------------------------------------------------------------
# After postencode — images materialized, ready for packing
# ---------------------------------------------------------------------------
@dataclass
class PackedSample:
    """Packed sample with all media materialized, ready for batching."""

    #: Token IDs (may be concatenation of multiple samples).
    tokens: torch.Tensor

    #: Labels.
    labels: torch.Tensor

    #: Materialized image tensors (C, H, W) — all tiles flattened.
    images: list[torch.Tensor]

    #: Number of tiles per original image.
    num_tiles: list[int]

    #: Cumulative sample lengths within this packed sequence.
    #: E.g. [0, 300, 620] means two sub-samples of length 300 and 320.
    cu_lengths: torch.Tensor

    #: Total padded length of this packed sequence.
    max_length: int
