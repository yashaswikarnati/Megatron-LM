# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Cooker for NVMINT/vjawa segments format.

Expected: sample["json"] has segments[] of {"type":"text","text":"..."} or
{"type":"image","image":"000"}. Images are individual JPGs in the shard
named {key}.{image_id}.jpg → decoded as sample["{image_id}.jpg"] or
sample["{image_id}"] depending on decoder.

Works with default decoder (images auto-decoded) or decoder:null (raw bytes).
"""

import json as _json

from megatron.energon.task_encoder.base import stateless
from megatron.energon.task_encoder.cooking import basic_sample_keys, cooker
from megatron.energon.task_encoder.multimodal.cookers._image_util import to_pil_image
from megatron.energon.task_encoder.multimodal.sample_types import (
    ImageRef,
    MultiModalSample,
)

IMAGE_TAG = "<image>"

# Common image extensions the webdataset decoder might use as keys
_IMG_EXTS = ("jpg", "jpeg", "png", "webp")


def _find_image_in_sample(sample, image_id):
    """Find an image by its ID in the sample dict.

    Webdataset groups files by base key, so {key}.000.jpg appears as
    sample["000.jpg"] or just sample["000"] after decoding.
    """
    # Try with extensions first
    for ext in _IMG_EXTS:
        k = f"{image_id}.{ext}"
        if k in sample:
            return sample[k]
    # Try bare id (if decoder stripped extension)
    if image_id in sample:
        return sample[image_id]
    return None


@stateless
@cooker(need_cache=False)
def cook_nvmint_segments(sample: dict) -> MultiModalSample:
    data = sample["json"]
    if isinstance(data, bytes):
        data = _json.loads(data)

    segments = data.get("segments", [])

    parts = []
    image_refs = []

    for seg in segments:
        if isinstance(seg, str):
            import ast
            seg = ast.literal_eval(seg)

        seg_type = seg.get("type", "")
        if seg_type == "text":
            parts.append(seg["text"])
        elif seg_type == "image":
            image_id = seg["image"]
            img_data = _find_image_in_sample(sample, image_id)
            if img_data is not None:
                img = to_pil_image(img_data)
                w, h = img.size
                image_refs.append(ImageRef(data=img, width=w, height=h))
                parts.append(IMAGE_TAG)

    text = "".join(parts)

    return MultiModalSample(
        **basic_sample_keys(sample),
        text=text,
        images=image_refs,
    )
