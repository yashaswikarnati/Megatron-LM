# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Configuration dataclasses for the multimodal task encoder.

All configuration is explicit — no global state, no get_args().
"""

from dataclasses import dataclass
from typing import Literal, Optional, Protocol, runtime_checkable


@runtime_checkable
class TokenizerProtocol(Protocol):
    """Minimal tokenizer interface. Any HuggingFace tokenizer satisfies this."""

    @property
    def pad_token_id(self) -> int: ...

    @property
    def eos_token_id(self) -> int: ...

    def encode(self, text: str, add_special_tokens: bool = ...) -> list[int]: ...

    def decode(self, token_ids: list[int], skip_special_tokens: bool = ...) -> str: ...


@dataclass(frozen=True)
class VisionConfig:
    """Vision encoder configuration — determines how images map to tokens.

    All fields must be provided at construction time. There are no defaults
    that silently change token counts.
    """

    #: Processed image height in pixels (e.g. 448).
    img_h: int

    #: Processed image width in pixels (e.g. 448).
    img_w: int

    #: Vision encoder patch size (e.g. 14 for ViT-L/14).
    patch_dim: int

    #: Vision model type — used for selecting pixel normalization stats.
    #: One of: "clip", "siglip", "internvit", "radio", "radio-g",
    #: "radio-so400m", "cradio-v1", "cradio-g", "huggingface".
    vision_model_type: str = "clip"

    #: Whether the vision encoder omits the class token.
    disable_vision_class_token: bool = False

    #: Class token length (typically 1).
    class_token_len: int = 1

    #: Merge 2x2 patches via pixel shuffle (divides token count by 4).
    pixel_shuffle: bool = False

    #: Merge 2x2 patches via convolution (divides token count by 4).
    conv_merging: bool = False

    #: Add tile delimiter tokens.
    use_tile_tags: bool = False

    #: Add break token between tiles.
    use_image_break_token: bool = False

    #: Maximum tiles per image. 1 = no tiling.
    max_num_tiles: int = 1

    #: Minimum tiles per image (for tiling strategies).
    min_num_tiles: int = 1

    #: Whether to use tiling (split images into NxM tile grid).
    use_tiling: bool = False

    #: Whether to add a thumbnail when using multiple tiles.
    use_thumbnail: bool = False

    #: Use area-weighted aspect ratio matching for tiling.
    use_area_weighted_aspect_ratio: bool = False

    # --- Dynamic resolution options ---

    #: Enable dynamic resolution (variable patches per image).
    dynamic_resolution: bool = False

    #: Use tiling-based aspect ratio with dynamic resolution processing.
    match_tiling_dynamic_resolution: bool = False

    #: Per-tile block-diagonal attention (masked tiling).
    masked_tiling_dynamic_resolution: bool = False

    #: Minimum patches for dynamic resolution.
    dynamic_resolution_min_patches: int = 4

    #: Maximum patches for dynamic resolution (0 = unlimited).
    dynamic_resolution_max_patches: int = 0

    #: Minimum pixel dimension for dynamic resolution.
    dynamic_resolution_min_side: Optional[int] = None

    #: Thumbnail area threshold (0.0–1.0) for adding thumbnail in dynamic resolution.
    thumbnail_area_threshold: float = 0.8

    #: Whether to apply data augmentation.
    apply_data_augment: bool = False


@dataclass(frozen=True)
class PackingConfig:
    """Packing and sequence configuration.

    Note: ``packing_buffer_size`` is passed directly to ``get_train_dataset()``
    — it is not part of this config.
    """

    #: Target packed sequence length in tokens.
    seq_length: int

    #: How to handle documents longer than seq_length.
    #: "truncate" = drop the tail.
    #: "split" = split at safe boundaries (between images), yield multiple chunks.
    split_strategy: Literal["truncate", "split"] = "truncate"

    #: Token ID used for padding.
    pad_id: int = 0

    #: Label value for positions to ignore in loss computation.
    ignore_index: int = -100

    #: Special token ID that represents a single image patch in the token stream.
    #: This placeholder is expanded to the actual number of vision tokens at encode time.
    image_token_id: int = -200
