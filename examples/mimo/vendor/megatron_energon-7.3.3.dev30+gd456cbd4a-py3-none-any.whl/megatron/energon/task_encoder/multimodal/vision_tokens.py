# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Standalone vision token computation — no megatron.core dependency.

Ported from megatron.core.models.vision.clip_vit_model.get_num_image_embeddings.
Pure arithmetic: given image dimensions and vision encoder config, compute how many
tokens the encoder will produce.
"""

import math


def get_num_image_embeddings(
    img_h: int,
    img_w: int,
    patch_dim: int,
    *,
    class_token_len: int = 1,
    disable_vision_class_token: bool = False,
    pixel_shuffle: bool = False,
    conv_merging: bool = False,
    use_tile_tags: bool = False,
    max_num_tiles: int = 1,
    use_image_break_token: bool = False,
) -> int:
    """Compute the number of vision tokens produced by a ViT encoder.

    This is a standalone port of the same function from megatron.core. It is
    pure math — no model weights, no CUDA, no imports.

    Args:
        img_h: Image height in pixels.
        img_w: Image width in pixels.
        patch_dim: Patch size (e.g. 14 for ViT-L/14).
        class_token_len: Length of the class token (typically 1).
        disable_vision_class_token: If True, no class token is added.
        pixel_shuffle: If True, patches are merged 2x2 → divide by 4.
        conv_merging: If True, convolutional merging 2x2 → divide by 4.
        use_tile_tags: If True, tile delimiter tokens are added.
        max_num_tiles: Maximum number of tiles (for tile tag calculation).
        use_image_break_token: If True, add break tokens between tiles.

    Returns:
        Number of vision tokens (embeddings) the encoder produces.
    """
    num_patches_per_dim_h = img_h // patch_dim
    num_patches_per_dim_w = img_w // patch_dim
    num_patches = num_patches_per_dim_h * num_patches_per_dim_w

    num_embeddings = num_patches

    # Class token
    if not disable_vision_class_token:
        num_embeddings += class_token_len

    # Pixel shuffle merges 2x2 patches into 1
    if pixel_shuffle:
        num_embeddings = math.ceil(num_embeddings / 4)

    # Convolution merging also reduces by 4x
    if conv_merging:
        num_embeddings = math.ceil(num_embeddings / 4)

    # Tile tags add delimiter tokens
    if use_tile_tags:
        # Begin-of-tile and end-of-tile tokens per tile, plus image-level tokens
        num_embeddings += 2  # tile begin + tile end

    # Image break token between tiles
    if use_image_break_token:
        # One break token per tile boundary
        num_embeddings += 1

    return num_embeddings
