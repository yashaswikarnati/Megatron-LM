# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

"""Lightweight wrapper that loads an mcore blend JSON as a MetadatasetV2."""

import json
from typing import Any, Dict, Literal, Optional, Sequence, Union

from megatron.energon.edataclass import edataclass
from megatron.energon.epathlib import EPath
from megatron.energon.flavors.webdataset.structs import DatasetSubset
from megatron.energon.metadataset.loader_interface import DatasetLoaderInterface, LoadedDatasetList
from megatron.energon.metadataset.metadataset_v2 import (
    BlendDatasetReference,
    DatasetReference,
    MetadatasetBlend,
    MetadatasetV2,
)
from megatron.energon.worker import WorkerConfig


def _parse_blend_list(items: list) -> list[tuple[float, str]]:
    """Parse mcore's alternating [weight, path, weight, path, ...] list."""
    assert len(items) % 2 == 0, f"Expected even number of items, got {len(items)}"
    pairs = []
    for i in range(0, len(items), 2):
        weight = float(items[i])
        path = items[i + 1]
        pairs.append((weight, path))
    return pairs


@edataclass
class McoreBlend(DatasetLoaderInterface):
    """Load an mcore blend JSON file as if it were a MetadatasetV2.

    Usage (wrapper YAML)::

        __module__: megatron.energon
        __class__: McoreBlend
        mcore_json: /path/to/blend.json

    The JSON is expected to have the mcore format::

        {"train": ["weight1", "path1", "weight2", "path2", ...], ...}

    Paths are prefixes — ``.bin`` is appended automatically.
    """

    path: EPath  # set by load_config
    mcore_json: str  # path to mcore blend JSON (absolute or relative to yaml)
    subflavors: Optional[Dict[str, Any]] = None  # default: {"cook": "bin_idx"}

    _inner: Optional[MetadatasetV2] = None

    def post_initialize(self, mds_path: Optional[EPath] = None) -> None:
        assert mds_path is None  # top-level, same contract as MetadatasetV2

        # Resolve JSON path relative to the YAML file
        if self.mcore_json.startswith("/"):
            json_path = EPath(self.mcore_json)
        else:
            json_path = self.path.parent / self.mcore_json

        with open(str(json_path)) as f:
            mcore = json.load(f)

        subflavors = self.subflavors or {"cook": "bin_idx"}

        # Map mcore split names to energon split names
        split_map = {"train": "train", "valid": "val", "test": "test"}

        splits: Dict[str, Union[MetadatasetBlend, DatasetReference]] = {}
        for mcore_name, energon_name in split_map.items():
            if mcore_name not in mcore:
                continue
            pairs = _parse_blend_list(mcore[mcore_name])
            if len(pairs) == 1:
                _weight, prefix = pairs[0]
                splits[energon_name] = DatasetReference(
                    path=prefix + ".bin",
                    subflavors=dict(subflavors),
                )
            else:
                blend_entries = []
                for weight, prefix in pairs:
                    blend_entries.append(
                        BlendDatasetReference(
                            weight=weight,
                            path=prefix + ".bin",
                            subflavors=dict(subflavors),
                        )
                    )
                splits[energon_name] = MetadatasetBlend(blend=blend_entries)

        self._inner = MetadatasetV2(path=self.path, splits=splits)
        self._inner.post_initialize()

    def prepare(self, split_part: Optional[str] = None) -> Sequence[EPath]:
        assert self._inner is not None, "Missing post_initialize call."
        return self._inner.prepare(split_part=split_part)

    def get_datasets(
        self,
        *,
        training: bool,
        split_part: Union[Literal["train", "val", "test"], str],
        worker_config: WorkerConfig,
        subflavors: Optional[Dict[str, Any]] = None,
        shuffle_over_epochs_multiplier: Optional[int] = 1,
        subset: Optional[DatasetSubset] = None,
        **kwargs,
    ) -> LoadedDatasetList:
        assert self._inner is not None, "Missing post_initialize call."
        return self._inner.get_datasets(
            training=training,
            split_part=split_part,
            worker_config=worker_config,
            subflavors=subflavors,
            shuffle_over_epochs_multiplier=shuffle_over_epochs_multiplier,
            subset=subset,
            **kwargs,
        )
